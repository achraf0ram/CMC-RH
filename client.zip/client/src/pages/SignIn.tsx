import { SignIn } from "../components/auth/SignIn";

const SignInPage = () => {
    return <SignIn />;
};

export default SignInPage;