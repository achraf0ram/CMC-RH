import { SignUp } from "../components/auth/SignUp";

const SignUpPage = () => {
    return <SignUp />;
};

export default SignUpPage;